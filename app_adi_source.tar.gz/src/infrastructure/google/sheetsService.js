// Stub de servicio Google Sheets API v4
// En producción: ejecuta operaciones CRUD contra el Spreadsheet del docente
// Actualmente: log + noop para desarrollo local

import { SHEET_NAMES, isGoogleConfigured } from './googleConfig'

let spreadsheetId = null

// Crear el Spreadsheet con todas las hojas del SRS 6.2 (Real)
export async function createSpreadsheet(title = 'ADI — Agenda Docente Inteligente') {
    if (!isGoogleConfigured()) return null

    try {
        const response = await gapi.client.sheets.spreadsheets.create({
            resource: {
                properties: { title },
                sheets: Object.values(SHEET_NAMES).map(name => ({
                    properties: { title: name }
                }))
            }
        })

        spreadsheetId = response.result.spreadsheetId
        console.log('[SheetsService] Spreadsheet creado:', spreadsheetId)

        return {
            spreadsheetId,
            spreadsheetUrl: response.result.spreadsheetUrl
        }
    } catch (error) {
        console.error('[SheetsService] Error al crear spreadsheet:', error)
        throw error
    }
}

// Vincular un Spreadsheet existente
export function setSpreadsheetId(id) {
    spreadsheetId = id
}

// Leer datos de una hoja (stub)
export async function readSheet(sheetName, range = '') {
    if (!isGoogleConfigured()) {
        console.info(`[SheetsService] Stub read: ${sheetName} ${range}`)
        return []
    }
    // En producción: gapi.client.sheets.spreadsheets.values.get(...)
    return []
}

// Agregar filas a una hoja (stub)
export async function appendRows(sheetName, values) {
    if (!isGoogleConfigured()) {
        console.info(`[SheetsService] Stub append to ${sheetName}:`, values.length, 'filas')
        return { updatedRows: values.length }
    }
    // En producción: gapi.client.sheets.spreadsheets.values.append(...)
    return null
}

// Actualizar filas en una hoja (stub)
export async function updateRows(sheetName, range, values) {
    if (!isGoogleConfigured()) {
        console.info(`[SheetsService] Stub update ${sheetName} ${range}:`, values)
        return { updatedRows: values.length }
    }
    // En producción: gapi.client.sheets.spreadsheets.values.update(...)
    return null
}

// Sincronizar un módulo completo (stub genérico)
export async function syncModule(sheetName, data, formatFn) {
    if (!isGoogleConfigured()) {
        console.info(`[SheetsService] Stub sync: ${sheetName}`, data.length, 'registros')
        return true
    }
    // En producción: clear + append de todos los datos formateados
    const formatted = data.map(formatFn)
    await appendRows(sheetName, formatted)
    return true
}

// Funciones de sincronización específicas por módulo

export async function syncStudents(students) {
    return syncModule(SHEET_NAMES.ALUMNOS, students, (s) => [
        s.id, s.name, s.lastName, s.dni, s.birthDate, s.phone, s.tutorEmail, s.courseId, s.status,
    ])
}

export async function syncAttendance(records) {
    const rows = []
    Object.entries(records).forEach(([key, dayRecord]) => {
        const [date, courseId] = key.split('_')
        Object.entries(dayRecord).forEach(([studentId, status]) => {
            rows.push([date, studentId, status, courseId])
        })
    })
    return syncModule(SHEET_NAMES.ASISTENCIA, rows, (r) => r)
}

export async function syncGrades(grades, subjects) {
    const rows = []
    Object.entries(grades).forEach(([key, noteArray]) => {
        const [studentId, subjectId] = key.split('_')
        const subject = subjects.find((s) => s.id === subjectId)
        rows.push([studentId, subject?.name || subjectId, ...noteArray])
    })
    return syncModule(SHEET_NAMES.NOTAS, rows, (r) => r)
}

export async function syncTopicBook(entries) {
    return syncModule(SHEET_NAMES.LIBRO_TEMAS, entries, (e) => [
        e.date, e.courseId, e.subject, e.topic, e.activity, e.homework || '',
    ])
}

export async function syncCalendarEvents(events) {
    return syncModule(SHEET_NAMES.AGENDA, events, (e) => [
        e.id, e.type, e.title, e.date, e.time || '', e.place || '', e.notes || '', (e.students || []).join(','),
    ])
}
