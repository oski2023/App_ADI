// Stub de servicio Google Calendar API v3
// En producción: sincroniza eventos del ciclo lectivo con Google Calendar
// Actualmente: log + noop para desarrollo local

import { isGoogleConfigured } from './googleConfig'

const CALENDAR_ID = 'primary'

// Crear evento en Google Calendar (stub)
export async function createCalendarEvent(event) {
    if (!isGoogleConfigured()) {
        console.info('[CalendarService] Stub createEvent:', event.title, event.date)
        return { id: `gcal_${event.id}`, ...event }
    }

    // En producción:
    // const calendarEvent = {
    //   summary: event.title,
    //   description: event.notes,
    //   location: event.place,
    //   start: { date: event.date },
    //   end: { date: event.date },
    //   reminders: { useDefault: false, overrides: [{ method: 'popup', minutes: 1440 }] },
    // }
    // return gapi.client.calendar.events.insert({ calendarId: CALENDAR_ID, resource: calendarEvent })
    return null
}

// Actualizar evento en Google Calendar (stub)
export async function updateCalendarEvent(eventId, event) {
    if (!isGoogleConfigured()) {
        console.info('[CalendarService] Stub updateEvent:', eventId)
        return event
    }
    // En producción: gapi.client.calendar.events.update(...)
    return null
}

// Eliminar evento de Google Calendar (stub)
export async function deleteCalendarEvent(eventId) {
    if (!isGoogleConfigured()) {
        console.info('[CalendarService] Stub deleteEvent:', eventId)
        return true
    }
    // En producción: gapi.client.calendar.events.delete(...)
    return true
}

// Listar eventos desde Google Calendar (stub)
export async function listCalendarEvents(timeMin, timeMax) {
    if (!isGoogleConfigured()) {
        console.info('[CalendarService] Stub listEvents:', timeMin, '→', timeMax)
        return []
    }
    // En producción: gapi.client.calendar.events.list(...)
    return []
}
