// Constantes y datos semilla para la aplicación

export const ATTENDANCE_STATES = {
    PRESENT: 'P',
    ABSENT: 'A',
    LATE: 'T',
}

export const ATTENDANCE_LABELS = {
    P: 'Presente',
    A: 'Ausente',
    T: 'Tarde',
}

export const ATTENDANCE_COLORS = {
    P: 'text-secondary',
    A: 'text-error',
    T: 'text-warning',
}

export const EVENT_TYPES = {
    HOLIDAY: 'feriado',
    PLENARY: 'plenaria',
    PARENTS: 'padres',
    EXAM: 'examen',
    OTHER: 'otro',
}

export const EVENT_COLORS = {
    feriado: '#C62828',
    plenaria: '#1A56A0',
    padres: '#2E7D32',
    examen: '#E65100',
    otro: '#64748B',
}

export const GRADE_STATUS = {
    APPROVED: 'aprobado',
    FAILED: 'reprobado',
    PENDING: 'pendiente',
}

export const DEFAULT_SETTINGS = {
    absenceThreshold: 25,
    gradeMin: 1,
    gradeMax: 10,
    passingGrade: 6,
    maxPartialGrades: 4,
}

// Datos de ejemplo para demostración
export const SEED_COURSES = [
    { id: 'c1', year: '3°', division: 'A', shift: 'Mañana', cycle: '2026', subjects: ['Matemática', 'Física'], teachers: ['Prof. García'] },
    { id: 'c2', year: '4°', division: 'B', shift: 'Tarde', cycle: '2026', subjects: ['Matemática', 'Álgebra'], teachers: ['Prof. García'] },
    { id: 'c3', year: '5°', division: 'A', shift: 'Mañana', cycle: '2026', subjects: ['Análisis Matemático'], teachers: ['Prof. García'] },
]

export const SEED_STUDENTS = [
    { id: 's1', name: 'Lucía', lastName: 'Fernández', dni: '45123456', birthDate: '2010-05-12', phone: '11-5555-1234', tutorEmail: 'mama.fernandez@gmail.com', courseId: 'c1', status: 'active', photo: null },
    { id: 's2', name: 'Mateo', lastName: 'González', dni: '45234567', birthDate: '2010-08-22', phone: '11-5555-2345', tutorEmail: 'papa.gonzalez@gmail.com', courseId: 'c1', status: 'active', photo: null },
    { id: 's3', name: 'Valentina', lastName: 'López', dni: '45345678', birthDate: '2010-03-15', phone: '11-5555-3456', tutorEmail: 'mama.lopez@gmail.com', courseId: 'c1', status: 'active', photo: null },
    { id: 's4', name: 'Benjamín', lastName: 'Martínez', dni: '45456789', birthDate: '2010-11-30', phone: '11-5555-4567', tutorEmail: 'papa.martinez@gmail.com', courseId: 'c1', status: 'active', photo: null },
    { id: 's5', name: 'Sofía', lastName: 'Rodríguez', dni: '45567890', birthDate: '2010-07-08', phone: '11-5555-5678', tutorEmail: 'mama.rodriguez@gmail.com', courseId: 'c2', status: 'active', photo: null },
    { id: 's6', name: 'Tomás', lastName: 'Díaz', dni: '45678901', birthDate: '2009-01-25', phone: '11-5555-6789', tutorEmail: 'papa.diaz@gmail.com', courseId: 'c2', status: 'active', photo: null },
    { id: 's7', name: 'Camila', lastName: 'Pérez', dni: '45789012', birthDate: '2009-09-14', phone: '11-5555-7890', tutorEmail: 'mama.perez@gmail.com', courseId: 'c2', status: 'active', photo: null },
    { id: 's8', name: 'Santiago', lastName: 'Romero', dni: '45890123', birthDate: '2008-04-18', phone: '11-5555-8901', tutorEmail: 'papa.romero@gmail.com', courseId: 'c3', status: 'active', photo: null },
    { id: 's9', name: 'Isabella', lastName: 'Morales', dni: '45901234', birthDate: '2008-12-01', phone: '11-5555-9012', tutorEmail: 'mama.morales@gmail.com', courseId: 'c3', status: 'active', photo: null },
    { id: 's10', name: 'Nicolás', lastName: 'Castro', dni: '46012345', birthDate: '2008-06-20', phone: '11-5555-0123', tutorEmail: 'papa.castro@gmail.com', courseId: 'c3', status: 'active', photo: null },
]

export const SEED_SUBJECTS = [
    { id: 'sub1', name: 'Matemática', year: '3°', section: 'A', weights: [25, 25, 25, 25] },
    { id: 'sub2', name: 'Física', year: '3°', section: 'A', weights: [30, 30, 40] },
    { id: 'sub3', name: 'Matemática', year: '4°', section: 'B', weights: [25, 25, 25, 25] },
    { id: 'sub4', name: 'Álgebra', year: '4°', section: 'B', weights: [50, 50] },
    { id: 'sub5', name: 'Análisis Matemático', year: '5°', section: 'A', weights: [20, 20, 20, 40] },
]

export const SEED_EVENTS = [
    { id: 'e1', type: 'feriado', title: 'Día de la Memoria', date: '2026-03-24', time: null, place: null, notes: 'Feriado nacional', students: [] },
    { id: 'e2', type: 'feriado', title: 'Día del Veterano', date: '2026-04-02', time: null, place: null, notes: 'Feriado nacional', students: [] },
    { id: 'e3', type: 'plenaria', title: 'Reunión de Plenaria', date: '2026-03-20', time: '18:00', place: 'Sala de profesores', notes: 'Planificación 1er trimestre', students: [] },
    { id: 'e4', type: 'padres', title: 'Reunión de Padres - 3°A', date: '2026-03-27', time: '19:00', place: 'Aula 3°A', notes: 'Presentación del ciclo lectivo', students: ['s1', 's2', 's3', 's4'] },
    { id: 'e5', type: 'examen', title: 'Primer Parcial - Matemática 3°A', date: '2026-04-15', time: '08:00', place: 'Aula 3°A', notes: 'Temas: Unidades 1-3', students: [] },
    { id: 'e6', type: 'feriado', title: 'Día del Trabajador', date: '2026-05-01', time: null, place: null, notes: 'Feriado nacional', students: [] },
    { id: 'e7', type: 'feriado', title: 'Día de la Revolución de Mayo', date: '2026-05-25', time: null, place: null, notes: 'Feriado nacional', students: [] },
]

export const MONTHS_ES = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
]

export const DAYS_ES = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb']
export const DAYS_FULL_ES = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado']
