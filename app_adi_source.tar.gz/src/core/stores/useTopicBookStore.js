import { create } from 'zustand'
import { persist } from 'zustand/middleware'

const useTopicBookStore = create(
    persist(
        (set, get) => ({
            entries: [
                { id: 't1', date: '2026-03-06', courseId: 'c1', subject: 'Matemática', topic: 'Números reales - Propiedades', activity: 'Clase teórica + ejercicios', homework: 'Ejercicios pág. 25-27' },
                { id: 't2', date: '2026-03-05', courseId: 'c1', subject: 'Física', topic: 'Introducción a la Cinemática', activity: 'Presentación y debate', homework: null },
                { id: 't3', date: '2026-03-04', courseId: 'c2', subject: 'Matemática', topic: 'Funciones cuadráticas', activity: 'Resolución de problemas', homework: 'TP Nro. 1' },
            ],

            addEntry: (entry) => set((state) => ({
                entries: [...state.entries, { ...entry, id: `t${Date.now()}` }],
            })),

            updateEntry: (id, data) => set((state) => ({
                entries: state.entries.map((e) => (e.id === id ? { ...e, ...data } : e)),
            })),

            deleteEntry: (id) => set((state) => ({
                entries: state.entries.filter((e) => e.id !== id),
            })),

            getEntriesByCourse: (courseId) =>
                get().entries.filter((e) => e.courseId === courseId).sort((a, b) => b.date.localeCompare(a.date)),

            getEntryByDateAndCourse: (date, courseId, subject) =>
                get().entries.find((e) => e.date === date && e.courseId === courseId && e.subject === subject),
        }),
        {
            name: 'adi_topicbook',
            partialize: (state) => ({ entries: state.entries }),
        }
    )
)

export default useTopicBookStore
