import { create } from 'zustand'

const useAuthStore = create((set) => ({
    user: {
        id: 'doc1',
        name: 'Prof. García',
        email: 'garcia.docente@gmail.com',
        avatar: null,
        role: 'Docente',
    },
    isAuthenticated: true,
    isLoading: false,

    login: () => set({ isAuthenticated: true }),
    logout: () => set({ isAuthenticated: false, user: null }),
    setUser: (user) => set({ user }),
}))

export default useAuthStore
