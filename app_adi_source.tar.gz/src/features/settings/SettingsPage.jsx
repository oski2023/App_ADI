import { useState } from 'react'
import { useShallow } from 'zustand/react/shallow'
import { Card, CardBody } from '../../shared/components/Card'
import Button from '../../shared/components/Button'
import Badge from '../../shared/components/Badge'
import { Input } from '../../shared/components/Input'
import { Settings, Link2, Shield, Bell, Palette, Save, ExternalLink, Check, Sun, Moon, Monitor } from 'lucide-react'
import useSettingsStore from '../../core/stores/useSettingsStore'
import useAuthStore from '../../core/stores/useAuthStore'
import toast from 'react-hot-toast'
import { signIn, signOut } from '../../infrastructure/google/googleAuth'
import { createSpreadsheet } from '../../infrastructure/google/sheetsService'

export default function SettingsPage() {
    const { settings, updateSettings, googleLinked, setGoogleLinked, darkMode, toggleDarkMode } = useSettingsStore(useShallow((s) => ({ settings: s.settings, updateSettings: s.updateSettings, googleLinked: s.googleLinked, setGoogleLinked: s.setGoogleLinked, darkMode: s.darkMode, toggleDarkMode: s.toggleDarkMode })))
    const { user, setUser } = useAuthStore(useShallow((s) => ({ user: s.user, setUser: s.setUser })))

    const [localSettings, setLocalSettings] = useState({ ...settings })
    const [isLinking, setIsLinking] = useState(false)

    const handleSave = () => {
        updateSettings(localSettings)
        toast.success('Configuración guardada exitosamente')
    }

    const handleGoogleConnection = async () => {
        setIsLinking(true)
        try {
            if (googleLinked) {
                await signOut()
                setGoogleLinked(false, null)
                toast.success('Cuenta desvinculada exitosamente')
            } else {
                const googleUser = await signIn()

                // Actualizar info de usuario con datos de Google
                setUser({
                    ...googleUser,
                    role: 'Docente'
                })

                // Crear Spreadsheet si no existe
                toast.loading('Creando base de datos en Google Sheets...', { id: 'g-sync' })
                const sheet = await createSpreadsheet()

                setGoogleLinked(true, sheet.spreadsheetUrl)
                toast.success('¡App vinculada y base de datos creada!', { id: 'g-sync' })
            }
        } catch (error) {
            console.error('Auth Error:', error)
            toast.error(error.error === 'popup_closed_by_user'
                ? 'Se cerró la ventana antes de completar'
                : 'Error al vincular con Google', { id: 'g-sync' })
        } finally {
            setIsLinking(false)
        }
    }

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-text-primary">Configuración</h1>
                    <p className="text-sm text-text-secondary mt-1">Personalizá la aplicación según tus necesidades</p>
                </div>
                <Button icon={Save} variant="primary" onClick={handleSave}>
                    Guardar Cambios
                </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Profile */}
                <Card>
                    <div className="px-5 py-4 border-b border-border-light flex items-center gap-2">
                        <Shield className="w-4 h-4 text-primary" />
                        <h2 className="text-base font-semibold text-text-primary">Perfil del Docente</h2>
                    </div>
                    <CardBody className="space-y-4">
                        <div className="flex items-center gap-4">
                            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-primary-light flex items-center justify-center text-white text-xl font-bold">
                                {user?.name?.charAt(0) || 'D'}
                            </div>
                            <div>
                                <p className="text-lg font-semibold text-text-primary">{user?.name}</p>
                                <p className="text-sm text-text-secondary">{user?.email}</p>
                                <Badge variant="primary" className="mt-1">{user?.role}</Badge>
                            </div>
                        </div>
                    </CardBody>
                </Card>

                {/* Appearance / Dark Mode */}
                <Card>
                    <div className="px-5 py-4 border-b border-border-light flex items-center gap-2">
                        <Palette className="w-4 h-4 text-primary" />
                        <h2 className="text-base font-semibold text-text-primary">Apariencia</h2>
                    </div>
                    <CardBody className="space-y-4">
                        <p className="text-sm text-text-secondary">Seleccioná el tema de la interfaz</p>
                        <div className="grid grid-cols-3 gap-3">
                            {[
                                { value: false, icon: Sun, label: 'Claro', colors: 'bg-amber-50 border-amber-200 text-amber-600' },
                                { value: true, icon: Moon, label: 'Oscuro', colors: 'bg-indigo-950 border-indigo-700 text-indigo-300' },
                            ].map(({ value, icon: Icon, label, colors }) => {
                                const isActive = darkMode === value
                                return (
                                    <button
                                        key={label}
                                        onClick={() => { if (darkMode !== value) toggleDarkMode() }}
                                        className={`relative flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-300 cursor-pointer ${isActive
                                            ? 'border-primary bg-primary/10 shadow-md ring-2 ring-primary/20'
                                            : 'border-border hover:border-primary/40 hover:shadow-sm'
                                            }`}
                                    >
                                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colors}`}>
                                            <Icon className="w-5 h-5" />
                                        </div>
                                        <span className={`text-sm font-medium ${isActive ? 'text-primary' : 'text-text-secondary'}`}>{label}</span>
                                        {isActive && (
                                            <div className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                                                <Check className="w-3 h-3 text-white" />
                                            </div>
                                        )}
                                    </button>
                                )
                            })}
                            <button
                                className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-border opacity-50 cursor-not-allowed"
                                disabled
                            >
                                <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-bg-hover">
                                    <Monitor className="w-5 h-5 text-text-muted" />
                                </div>
                                <span className="text-sm font-medium text-text-muted">Sistema</span>
                                <span className="text-[10px] text-text-muted">Próximamente</span>
                            </button>
                        </div>
                    </CardBody>
                </Card>

                {/* Google Integration */}
                <Card>
                    <div className="px-5 py-4 border-b border-border-light flex items-center gap-2">
                        <Link2 className="w-4 h-4 text-primary" />
                        <h2 className="text-base font-semibold text-text-primary">Integración Google Workspace</h2>
                    </div>
                    <CardBody className="space-y-4">
                        <div className="flex items-center justify-between p-3 rounded-xl bg-bg-hover">
                            <div>
                                <p className="text-sm font-medium text-text-primary">Google Sheets</p>
                                <p className="text-xs text-text-secondary">Sincronización de datos</p>
                            </div>
                            <Badge variant={googleLinked ? 'success' : 'neutral'} dot>{googleLinked ? 'Conectado' : 'Desconectado'}</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-xl bg-bg-hover">
                            <div>
                                <p className="text-sm font-medium text-text-primary">Google Drive</p>
                                <p className="text-xs text-text-secondary">Almacenamiento y backup</p>
                            </div>
                            <Badge variant={googleLinked ? 'success' : 'neutral'} dot>{googleLinked ? 'Conectado' : 'Desconectado'}</Badge>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-xl bg-bg-hover">
                            <div>
                                <p className="text-sm font-medium text-text-primary">Google Calendar</p>
                                <p className="text-xs text-text-secondary">Sincronización de eventos</p>
                            </div>
                            <Badge variant={googleLinked ? 'success' : 'neutral'} dot>{googleLinked ? 'Conectado' : 'Desconectado'}</Badge>
                        </div>
                        <Button
                            variant={googleLinked ? 'outline' : 'primary'}
                            icon={ExternalLink}
                            onClick={handleGoogleConnection}
                            loading={isLinking}
                            disabled={isLinking}
                            className="w-full"
                        >
                            {googleLinked ? 'Desvincular Google' : 'Vincular con Google'}
                        </Button>
                    </CardBody>
                </Card>

                {/* Academic Settings */}
                <Card>
                    <div className="px-5 py-4 border-b border-border-light flex items-center gap-2">
                        <Settings className="w-4 h-4 text-primary" />
                        <h2 className="text-base font-semibold text-text-primary">Configuración Académica</h2>
                    </div>
                    <CardBody className="space-y-4">
                        <Input
                            id="threshold" type="number" label="Umbral de Inasistencia (%)"
                            value={localSettings.absenceThreshold}
                            onChange={(e) => setLocalSettings({ ...localSettings, absenceThreshold: parseInt(e.target.value) || 0 })}
                        />
                        <Input
                            id="passingGrade" type="number" label="Nota de Aprobación"
                            value={localSettings.passingGrade}
                            onChange={(e) => setLocalSettings({ ...localSettings, passingGrade: parseInt(e.target.value) || 0 })}
                        />
                        <div className="grid grid-cols-2 gap-4">
                            <Input
                                id="gradeMin" type="number" label="Nota Mínima"
                                value={localSettings.gradeMin}
                                onChange={(e) => setLocalSettings({ ...localSettings, gradeMin: parseInt(e.target.value) || 0 })}
                            />
                            <Input
                                id="gradeMax" type="number" label="Nota Máxima"
                                value={localSettings.gradeMax}
                                onChange={(e) => setLocalSettings({ ...localSettings, gradeMax: parseInt(e.target.value) || 0 })}
                            />
                        </div>
                        <Input
                            id="maxPartials" type="number" label="Máx. Notas Parciales"
                            value={localSettings.maxPartialGrades}
                            onChange={(e) => setLocalSettings({ ...localSettings, maxPartialGrades: parseInt(e.target.value) || 0 })}
                        />
                    </CardBody>
                </Card>

                {/* Notifications */}
                <Card>
                    <div className="px-5 py-4 border-b border-border-light flex items-center gap-2">
                        <Bell className="w-4 h-4 text-primary" />
                        <h2 className="text-base font-semibold text-text-primary">Notificaciones</h2>
                    </div>
                    <CardBody className="space-y-3">
                        {[
                            { label: 'Alertas de inasistencia', desc: 'Cuando un alumno supera el umbral configurado', enabled: true },
                            { label: 'Recordatorio de eventos', desc: '24 hs antes de cada evento en la agenda', enabled: true },
                            { label: 'Notas pendientes', desc: 'Recordatorio de notas faltantes por cargar', enabled: false },
                            { label: 'Reportes automáticos', desc: 'Generación automática de reporte semanal', enabled: false },
                        ].map((item, i) => (
                            <div key={i} className="flex items-center justify-between p-3 rounded-xl hover:bg-bg-hover transition-colors">
                                <div>
                                    <p className="text-sm font-medium text-text-primary">{item.label}</p>
                                    <p className="text-xs text-text-secondary">{item.desc}</p>
                                </div>
                                <button
                                    className={`w-11 h-6 rounded-full transition-colors duration-200 cursor-pointer relative ${item.enabled ? 'bg-primary' : 'bg-border'}`}
                                    onClick={() => { }}
                                >
                                    <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform duration-200 ${item.enabled ? 'left-5.5' : 'left-0.5'}`} />
                                </button>
                            </div>
                        ))}
                    </CardBody>
                </Card>
            </div>
        </div>
    )
}
