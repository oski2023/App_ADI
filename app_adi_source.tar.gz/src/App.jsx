import { BrowserRouter, Routes, Route } from 'react-router-dom'
import AppLayout from './shared/components/AppLayout'
import DashboardPage from './features/dashboard/DashboardPage'
import CoursesPage from './features/courses/CoursesPage'
import StudentsPage from './features/students/StudentsPage'
import AttendancePage from './features/attendance/AttendancePage'
import GradesPage from './features/grades/GradesPage'
import TopicBookPage from './features/topic-book/TopicBookPage'
import PlanningPage from './features/planning/PlanningPage'
import CalendarPage from './features/calendar/CalendarPage'
import ReportsPage from './features/reports/ReportsPage'
import SettingsPage from './features/settings/SettingsPage'

import { Toaster } from 'react-hot-toast'

import { useEffect } from 'react'
import useSyncStore from './infrastructure/google/syncManager'

export default function App() {
    const initSync = useSyncStore((s) => s.init)

    useEffect(() => {
        initSync()
    }, [initSync])

    return (
        <BrowserRouter>
            <Routes>
                <Route element={<AppLayout />}>
                    <Route path="/" element={<DashboardPage />} />
                    <Route path="/courses" element={<CoursesPage />} />
                    <Route path="/students" element={<StudentsPage />} />
                    <Route path="/attendance" element={<AttendancePage />} />
                    <Route path="/grades" element={<GradesPage />} />
                    <Route path="/topic-book" element={<TopicBookPage />} />
                    <Route path="/planning" element={<PlanningPage />} />
                    <Route path="/calendar" element={<CalendarPage />} />
                    <Route path="/reports" element={<ReportsPage />} />
                    <Route path="/settings" element={<SettingsPage />} />
                </Route>
            </Routes>
            <Toaster position="bottom-right" toastOptions={{ className: 'text-sm font-medium rounded-lg shadow-lg' }} />
        </BrowserRouter>
    )
}
